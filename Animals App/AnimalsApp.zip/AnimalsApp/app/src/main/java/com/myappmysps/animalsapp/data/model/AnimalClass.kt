package com.myappmysps.animalsapp.data.model

data class AnimalClass(
    val name:String="",
    val description:String="",
    val image:Int=1
)
